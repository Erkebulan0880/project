import sys
from pathlib import Path

# Добавляем путь к проекту
project_path = str(Path(__file__).parent)
if project_path not in sys.path:
    sys.path.append(project_path)

# Теперь импортируем Django и настраиваем
import django
import os

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'iq_test.settings')
django.setup()

# Запускаем миграции
from django.core.management import execute_from_command_line
execute_from_command_line(['manage.py', 'makemigrations'])