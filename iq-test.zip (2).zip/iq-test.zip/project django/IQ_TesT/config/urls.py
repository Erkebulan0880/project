from django.contrib import admin
from django.urls import path
from iq_test import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('test/', views.test, name='test'),
    path('results/', views.results, name='results'),
]