import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'iq_test.settings')
django.setup()

from quiz.models import Question, Answer

questions_data = [
    {
        'text': 'Какое число продолжает последовательность: 2, 4, 8, 16, ...?',
        'difficulty': 1,
        'answers': [
            {'text': '24', 'is_correct': False},
            {'text': '32', 'is_correct': True},
            {'text': '64', 'is_correct': False},
            {'text': '20', 'is_correct': False},
        ]
    },
    {
        'text': 'Если все кошки - животные, и все животные - млекопитающие, то все кошки - млекопитающие?',
        'difficulty': 2,
        'answers': [
            {'text': 'Да', 'is_correct': True},
            {'text': 'Нет', 'is_correct': False},
            {'text': 'Недостаточно информации', 'is_correct': False},
        ]
    },
    {
        'text': 'Какое слово лишнее: яблоко, банан, морковь, апельсин?',
        'difficulty': 3,
        'answers': [
            {'text': 'яблоко', 'is_correct': False},
            {'text': 'банан', 'is_correct': False},
            {'text': 'морковь', 'is_correct': True},
            {'text': 'апельсин', 'is_correct': False},
        ]
    },
    {
        'text': 'Продолжите последовательность: А, В, Г, Д, ...',
        'difficulty': 4,
        'answers': [
            {'text': 'Е', 'is_correct': True},
            {'text': 'Ж', 'is_correct': False},
            {'text': 'З', 'is_correct': False},
            {'text': 'И', 'is_correct': False},
        ]
    },
    {
        'text': 'Если некоторые птицы - пингвины, и все пингвины не умеют летать, значит ли это, что некоторые птицы не умеют летать?',
        'difficulty': 5,
        'answers': [
            {'text': 'Да', 'is_correct': True},
            {'text': 'Нет', 'is_correct': False},
            {'text': 'Нельзя определить', 'is_correct': False},
        ]
    }
]

for q_data in questions_data:
    question = Question.objects.create(text=q_data['text'], difficulty=q_data['difficulty'])
    for a_data in q_data['answers']:
        Answer.objects.create(
            question=question,
            text=a_data['text'],
            is_correct=a_data['is_correct']
        )

print("5 вопросов создано успешно!")