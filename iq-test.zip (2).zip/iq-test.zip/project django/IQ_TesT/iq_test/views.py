from django.shortcuts import render, redirect
from .models import Question, Answer, TestResult
import random


def home(request):
    return render(request, 'quiz/home.html')


def test(request):
    questions = list(Question.objects.all())
    if len(questions) > 5:
        questions = random.sample(questions, 5)

    if request.method == 'POST':
        score = 0
        for question in questions:
            selected_answer = request.POST.get(f'question_{question.id}')
            if selected_answer:
                answer = Answer.objects.get(id=selected_answer)
                if answer.is_correct:
                    score += question.difficulty

        iq_estimate = "85-100" if score < 10 else "100-115" if score < 15 else "115-130" if score < 20 else "130+"

        if 'user_name' in request.POST:
            TestResult.objects.create(
                user_name=request.POST['user_name'],
                score=score,
                iq_estimate=iq_estimate
            )

        return render(request, 'quiz/result.html', {
            'score': score,
            'total': sum(q.difficulty for q in questions),
            'iq_estimate': iq_estimate
        })

    questions_with_answers = []
    for question in questions:
        answers = list(question.answers.all())
        random.shuffle(answers)
        questions_with_answers.append({
            'question': question,
            'answers': answers
        })

    return render(request, 'quiz/test.html', {
        'questions': questions_with_answers
    })


def results(request):
    all_results = TestResult.objects.all().order_by('-created_at')
    return render(request, 'quiz/all_results.html', {'results': all_results})